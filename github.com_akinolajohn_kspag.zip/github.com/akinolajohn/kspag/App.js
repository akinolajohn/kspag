import React from 'react';
import {
  View,
  Text,
  Image,
  Button,
  ScrollView,
  TouchableOpacity,
  TextInput
} from 'react-native';
import { StackNavigator } from 'react-navigation';

import {
  Container,
  Content,
  Header,
  Left,
  Body,
  Right,
  Icon,
  Card,
  CardItem,
  Title,
  Form,
  Item,
  Input,
  
} from 'native-base';

class HeaderSection extends React.Component {
  render() {
    return (
      <Container
        style={{
          backgroundColor: '#fff',
        }}>
        <Content>
          <Image
            source={require('./kspag.png')}
            style={{
              width: '50',
            }}
          />
          <TouchableOpacity>
            <Button
              title="Buy Now---> "
              onPress={() => this.props.navigation.navigate('Menu')}
              color="red"
              accessibilityLabel="Learn more about Kspag"
            />
          </TouchableOpacity>

          <Button
            title="You can Sign Up Here "
            onPress={() => this.props.navigation.navigate('SignUp')}
            color="red"
          />
        </Content>
      </Container>
    );
  }
}
class MenuScreen extends React.Component {
  render() {
    return (
      // Try setting `flexDirection` to `column`.

      <Container>
        <Header>
          <Left />
          <Body>
            <Title>Menu</Title>
          </Body>
          <Right />
        </Header>

        <ScrollView>
          <Content style={{ flex: 1 }}>
            //1ST MENU ITEM START
            <TouchableOpacity>
              <Card style={{ flex: 1, flexDirection: 'row' }}>
                <Image
                  source={require('./spag1.jpg')}
                  style={{
                    width: 150,
                    height: 110,
                  }}
                />
                <Text
                  style={{
                    flex: 1,
                    margin: 15,
                    width: 150,
                    fontSize: 20,
                    fontWeight: 'bold',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  Grilled Spaghetti and Chicken N600
                  <Button
                    title="Place Order "
                    onPress={() => this.props.navigation.navigate('OrderPage')}
                    color="red"
                    accessibilityLabel="Learn more about Kspag"
                  />
                </Text>
              </Card>
            </TouchableOpacity>
            //1ST MENU ITEM END //2ND MENU ITEM START
            <TouchableOpacity>
              <Card style={{ flex: 1, flexDirection: 'row' }}>
                <Image
                  source={require('./yamandegg.jpg')}
                  style={{
                    width: 150,
                    height: 110,
                  }}
                />
                <Text
                  style={{
                    flex: 1,
                    margin: 15,
                    width: 150,
                    fontSize: 20,
                    fontWeight: 'bold',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  Freshly Fried yam and Egg N600
                  <Button
                    title="Place Order "
                    onPress={() => this.props.navigation.navigate('OrderPage')}
                    color="red"
                    accessibilityLabel="Learn more about Kspag"
                  />
                </Text>
              </Card>
            </TouchableOpacity>
            //2ND MENU ITEM END 
            
            //3RD MENU ITEM START
            <TouchableOpacity>
              <Card style={{ flex: 1, flexDirection: 'row' }}>
                <Image
                  source={require('./riceandchicken.jpg')}
                  style={{
                    width: 150,
                    height: 110,
                  }}
                />
                <Text
                  style={{
                    flex: 1,
                    margin: 15,
                    width: 150,
                    fontSize: 20,
                    fontWeight: 'bold',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  Hot White Rice and Chicken N600
                  <Button
                    title="Place Order "
                    onPress={() => this.props.navigation.navigate('OrderPage')}
                    color="red"
                    accessibilityLabel="Learn more about Kspag"
                  />
                </Text>
              </Card>
        
            </TouchableOpacity>
            //3RD MENU ITEM END
            
            //4th MENU ITEM START
            <TouchableOpacity>
              <Card style={{ flex: 1, flexDirection: 'row' }}>
                <Image
                  source={require('./kspag.jpg')}
                  style={{
                    width: 150,
                    height: 110,
                  }}
                />
                <Text
                  style={{
                    flex: 1,
                    margin: 15,
                    width: 150,
                    fontSize: 20,
                    fontWeight: 'bold',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  Hot Special N1,000
                  <Button
                    title="Place Order "
                    onPress={() => this.props.navigation.navigate('OrderPage')}
                    color="red"
                    accessibilityLabel="Learn more about Kspag"
                  />
                </Text>
              </Card>
        
            </TouchableOpacity>
            // 4th MENU ITEM END
            
          </Content>
        </ScrollView>
      </Container>
    );
  }
}

class HomeScreen extends React.Component {
  render() {
    return (
      <View>
        <Text>Home Page</Text>
        <Button
          title="Log in "
          onPress={() => this.props.navigation.navigate('Login')}
        />

        <Button
          title="Sign Up "
          onPress={() => this.props.navigation.navigate('SignUp')}
        />

        <Button
          title=" Order Page "
          onPress={() => this.props.navigation.navigate('OrderPage')}
        />
      </View>
    );
  }
}

class LoginScreen extends React.Component {
  render() {
    return (
        
         <Container  style={{
             justifyContent:'center',contentAlign:"center"
            }}> 
         
          <Image
            source={require('./kspag.png')}
            style={{
              width:100,height:100,}}
          />
        <Content>
          <Form placeholder="Username" >
            <Item>
              <Input placeholder="Username" />
            </Item>
            <Item last>
             <Input secureTextEntry={true} placeholder="Password" />
            </Item>
          </Form>
          <Left />
        <Button 
          title=" Login "
          onPress={() => this.props.navigation.navigate('Menu')}
        />   
        </Content>
      </Container>
      
      
      
    );
  }
}

class SignUpScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Already Signed in ? </Text>
        <Button
          title=" Log in Here"
          onPress={() => this.props.navigation.push('Login')}
        />
        <Button
          title="Go to Home"
          onPress={() => this.props.navigation.navigate('Home')}
        />
        <Button
          title="Go back"
          onPress={() => this.props.navigation.goBack()}
        />
      </View>
    );
  }
}

class OrderScreen extends React.Component {
  render() {
    return (
   <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor:'none' }}>
        <Text>Almost there... </Text>
        <Image
            source={require('./kspag.png')}
            style={{
              width:200,height:200,}}
          />

          <TouchableOpacity>
            <Button
              title=" Confirm Order "
              onPress={() => this.props.navigation.navigate('ConfirmOrder')}
              color="red"
              accessibilityLabel="Learn more about Kspag"
            />
          </TouchableOpacity>


      </View>
    );
  }
}

class ConfirmOrderScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Place Your Order</Text>

        <Button
          title="Go to Home"
          onPress={() => this.props.navigation.navigate('Home')}
        />
        <Button
          title="Proceed to final Checkout"
          onPress={() => this.props.navigation.navigate('FinalCheckout')}
        />
        <Button
          title="Go back"
          onPress={() => this.props.navigation.goBack()}
        />
      </View>
    );
  }
}
class FinalCheckoutScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Make Payments </Text>

        <Button
          title="Go to Home"
          onPress={() => this.props.navigation.navigate('Home')}
        />
        <Button
          title="Go back"
          onPress={() => this.props.navigation.goBack()}
        />
      </View>
    );
  }
}

const RootStack = StackNavigator(
  {
    Home: {
      screen: MenuScreen,
    },
    Login: {
      screen: LoginScreen,
    },
    SignUp: {
      screen: SignUpScreen,
    },
    OrderPage: {
      screen: OrderScreen,
    },
    ConfirmOrder: {
      screen: ConfirmOrderScreen,
    },
    FinalCheckout: {
      screen: FinalCheckoutScreen,
    },
    Head: {
      screen: HeaderSection,
    },
    Menu: {
      screen: MenuScreen,
    },
  },
  {
    initialRouteName: 'Login',
  }
);

export default class App extends React.Component {
  render() {
    return <RootStack />;
  }
}
