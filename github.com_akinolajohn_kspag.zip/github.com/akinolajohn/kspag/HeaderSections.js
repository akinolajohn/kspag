import React from 'react';
import { View, Text, Button } from 'react-native';
import { StackNavigator } from 'react-navigation'; 
import { Container,Content, Header, Left, Body, Right, Icon,Card,CardItem, Title} from "native-base";

class HeaderSections extends React.Component{
render(){
  return(
    
        <Text>Home Page ooo </Text>
        <Button
          title="Log in "
          onPress={() => this.props.navigation.navigate('Login')}
        />  
      
        <Button
          title="Sign Up "
          onPress={() => this.props.navigation.navigate('SignUp')}
        />

          <Button
          title=" Order Page "
          onPress={() => this.props.navigation.navigate('OrderPage')}
        />
  );
}
}

export {HeaderSection}