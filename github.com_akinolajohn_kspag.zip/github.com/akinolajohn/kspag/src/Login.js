import React, { Component,StyleSheet} from 'react';
import { Container, Header, Content, Form, Item, Input } from 'native-base';


export default class FormExample extends Component {
  render() {
    return (
      <Container styles = {styles.container}>
        <Header />
        <Content>
          <Form>
            <Item>
              <Input placeholder="Username" />
            </Item>
            <Item last>
              <Input placeholder="Password" />
            </Item>
          </Form>
        </Content>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
Container:{
  
  backgroungColor:'black'
},

}); 