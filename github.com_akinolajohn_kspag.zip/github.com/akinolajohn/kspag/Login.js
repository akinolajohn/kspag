import React, { Component} from 'react';
import { Container, Header, Content, Form, Item, Input,Button,Text } from 'native-base';
import { StyleSheet, Image } from 'react-native';

class Login extends React.Component {
  render() {
    return (
      <Container style={styles.container}>
        <Header />
       
          <Form>
            <Item>
              <Input placeholder="Username" />
            </Item>
            <Item>
              <Input placeholder="Password" />
            </Item>
          <Button bordered light style={{marginTop:5 }}>
            <Text style={styles.loginButton}>Login</Text>
          </Button>
          </Form>
       
      </Container>
    );
  }
}


const styles = StyleSheet.create({
  container: {
  backgroundColor:'white',
  
  },
loginButton:{
  color:'#3a0604'
}

});


export default Login;

    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>

    <Text>Login Page</Text>
        
        <Button
          title="Refresh Page"
          onPress={() => this.props.navigation.push('Login')}
        />
        <Button
          title="Go to Home"
          onPress={() => this.props.navigation.navigate('Home')}
        />
        <Button
          title="Go back"
          onPress={() => this.props.navigation.goBack()}
        />
        
      </View>
      
      
      